package com.examen.SaludSa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaludSaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaludSaApplication.class, args);
	}

}
