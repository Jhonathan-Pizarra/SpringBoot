package com.examen.SaludSa.controller;

public class HorarioController {

}
