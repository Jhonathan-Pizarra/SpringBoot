package com.examen.SaludSa.model;
import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
public class Horario implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idHorario;
	//@Temporal(TemporalType.TIME) 
	private String dia;
	//@Temporal(TemporalType.TIME) 
	private String horaInicio;
	//@Temporal(TemporalType.TIME) 
	private String horaFin;

}
