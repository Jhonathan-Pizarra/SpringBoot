package com.examen.SaludSa.service;

import java.util.List;
import com.examen.SaludSa.model.Departamento;

public interface IDepartamentoService {

	public void insertarDepartamento(Departamento nuevo);
	
	public List<Departamento> listarDepartamentos();
}
