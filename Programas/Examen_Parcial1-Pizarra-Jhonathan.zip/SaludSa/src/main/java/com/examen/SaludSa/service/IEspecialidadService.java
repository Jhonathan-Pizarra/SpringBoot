package com.examen.SaludSa.service;

import java.util.List;
import com.examen.SaludSa.model.Especialidad;

public interface IEspecialidadService {

	public void insertarEspecialidad(Especialidad nuevo);
	
	public List<Especialidad> listarEspecialidades();
}
