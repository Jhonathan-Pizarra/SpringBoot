package com.examen.SaludSa.service;

import java.util.List;
import com.examen.SaludSa.model.Horario;

public interface IHorarioService {

	public void insertarHorario(Horario nuevo);
	
	public List<Horario> listarHorarios();
}
