package com.examen.SaludSa.service;

import java.util.List;
import com.examen.SaludSa.model.Medico;

public interface IMedicoService {
	
	public void insertarMedico(Medico nuevo);
	
	public List<Medico> listarMedicos();

}
