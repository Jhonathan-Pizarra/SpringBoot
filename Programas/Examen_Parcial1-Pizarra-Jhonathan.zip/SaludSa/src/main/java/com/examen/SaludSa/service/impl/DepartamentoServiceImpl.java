package com.examen.SaludSa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.examen.SaludSa.model.Departamento;
import com.examen.SaludSa.repository.IDepartamentoRepository;
import com.examen.SaludSa.service.IDepartamentoService;

@Service
@Component
public class DepartamentoServiceImpl implements IDepartamentoService {

	@Autowired
	private IDepartamentoRepository repo;
	
	@Override
	public void insertarDepartamento(Departamento nuevo) {
		// TODO Auto-generated method stub
		repo.save(nuevo);
	}

	@Override
	public List<Departamento> listarDepartamentos() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
