package com.examen.SaludSa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.examen.SaludSa.model.Especialidad;
import com.examen.SaludSa.repository.IEspecialidadRepository;
import com.examen.SaludSa.service.IEspecialidadService;

@Service
@Component
public class EspecialidadServiceImpl implements IEspecialidadService {

	@Autowired
	private IEspecialidadRepository repo;
	
	@Override
	public void insertarEspecialidad(Especialidad nuevo) {
		// TODO Auto-generated method stub
		repo.save(nuevo);
		
	}

	@Override
	public List<Especialidad> listarEspecialidades() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
