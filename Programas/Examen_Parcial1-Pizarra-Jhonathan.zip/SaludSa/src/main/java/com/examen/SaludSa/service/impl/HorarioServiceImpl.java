package com.examen.SaludSa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.examen.SaludSa.model.Horario;
import com.examen.SaludSa.repository.IHorarioRepository;
import com.examen.SaludSa.service.IHorarioService;

@Service
@Component
public class HorarioServiceImpl implements IHorarioService {

	@Autowired
	private IHorarioRepository repo;
	
	@Override
	public void insertarHorario(Horario nuevo) {
		// TODO Auto-generated method stub
		repo.save(nuevo);
		
	}

	@Override
	public List<Horario> listarHorarios() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	
}
