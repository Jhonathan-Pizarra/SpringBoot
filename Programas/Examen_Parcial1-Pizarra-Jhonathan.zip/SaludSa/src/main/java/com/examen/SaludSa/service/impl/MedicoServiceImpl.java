package com.examen.SaludSa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.examen.SaludSa.model.Medico;
import com.examen.SaludSa.repository.IMedicoRepository;
import com.examen.SaludSa.service.IMedicoService;


@Service
@Component
public class MedicoServiceImpl implements IMedicoService {

	@Autowired
	private IMedicoRepository repo;
	
	@Override
	public void insertarMedico(Medico nuevo) {
		// TODO Auto-generated method stub
		repo.save(nuevo);
		
	}

	@Override
	public List<Medico> listarMedicos() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
