package com.examen.SaludSa;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.examen.SaludSa.model.Departamento;
import com.examen.SaludSa.model.Especialidad;
import com.examen.SaludSa.model.Horario;
import com.examen.SaludSa.model.Medico;
import com.examen.SaludSa.service.IDepartamentoService;
import com.examen.SaludSa.service.IEspecialidadService;
import com.examen.SaludSa.service.IHorarioService;
import com.examen.SaludSa.service.IMedicoService;

@SpringBootTest
class SaludSaApplicationTests {
	
	@Autowired
	private IMedicoService servicioMedico;
	
	@Autowired
	private IHorarioService servicioHorario;
	
	@Autowired
	private IEspecialidadService servicioEspecialidad;
	
	@Autowired
	private IDepartamentoService servicioDepartamento;

	@Test
	void contextLoads() {
		
		Medico nuevo = new Medico();
		nuevo.setNombre("Jhonathan");
		nuevo.setApellido("Pizarra");
		nuevo.setDireccion("Solanda");
		nuevo.setCorreo("jhonathan@mail.com");
		nuevo.setTelefono("0990809090");
		
		//Insert Medico
		servicioMedico.insertarMedico(nuevo);
		
		Medico nuevo2 = new Medico();
		nuevo2.setNombre("Chiriboga");
		nuevo2.setApellido("Xavier");
		nuevo2.setDireccion("Solanda");
		nuevo2.setCorreo("jhonathan2@mail.com");
		nuevo2.setTelefono("0990809091");
		
		//Insert Medico
		servicioMedico.insertarMedico(nuevo2);
		
		
		
		Horario nuevoHorario = new Horario();
		nuevoHorario.setDia("2024-01-24");
		nuevoHorario.setHoraInicio("20:00");
		nuevoHorario.setHoraFin("23:30");
		
		//Insertar Horario
		servicioHorario.insertarHorario(nuevoHorario);
		
		
		Especialidad nuevaEsp = new Especialidad();
		nuevaEsp.setNombreEspecialidad("Medicina General");
		
		//Insertar Especialidad
		servicioEspecialidad.insertarEspecialidad(nuevaEsp);
		
		Departamento nuevoDep = new Departamento();
		nuevoDep.setNombreDepartamento("Departamento ABC");
		
		servicioDepartamento.insertarDepartamento(nuevoDep);
		
		
		
	}

}
