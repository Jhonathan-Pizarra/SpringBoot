package com.uisrael.ticketsOnline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketsOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketsOnlineApplication.class, args);
	}

}
