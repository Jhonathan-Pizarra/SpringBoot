package com.uisrael.ticketsOnline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketsOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
